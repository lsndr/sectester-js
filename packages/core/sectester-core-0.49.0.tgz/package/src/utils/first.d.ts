export declare const first: <T>(promises: PromiseLike<T>[], predicate: (value: T) => unknown) => Promise<T | undefined>;
