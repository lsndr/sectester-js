"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JUnitReportBuilder = exports.buildJUnitXML = void 0;
var build_junit_xml_1 = require("./build-junit-xml");
Object.defineProperty(exports, "buildJUnitXML", { enumerable: true, get: function () { return build_junit_xml_1.buildJUnitXML; } });
var JUnitReportBuilder_1 = require("./JUnitReportBuilder");
Object.defineProperty(exports, "JUnitReportBuilder", { enumerable: true, get: function () { return JUnitReportBuilder_1.JUnitReportBuilder; } });
//# sourceMappingURL=index.js.map