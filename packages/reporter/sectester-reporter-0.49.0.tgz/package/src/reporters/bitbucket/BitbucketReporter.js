"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BitbucketReporter = void 0;
const tslib_1 = require("tslib");
const api_1 = require("./api");
const builders_1 = require("./builders");
const utils_1 = require("../../utils");
const junit_1 = require("../../junit");
const tsyringe_1 = require("tsyringe");
const promises_1 = require("node:fs/promises");
const node_crypto_1 = require("node:crypto");
const node_path_1 = require("node:path");
let BitbucketReporter = class BitbucketReporter {
    constructor(config, bitbucketClient, testFilePathResolver) {
        this.config = config;
        this.bitbucketClient = bitbucketClient;
        this.testFilePathResolver = testFilePathResolver;
        // Token is only required when NOT using the Pipelines proxy
        // The proxy automatically handles authentication
        if (!this.config.usePipelinesProxy && !this.config.token) {
            throw new Error('Bitbucket token is not set');
        }
        if (!this.config.workspace) {
            throw new Error('Bitbucket workspace is not set');
        }
        if (!this.config.repoSlug) {
            throw new Error('Bitbucket repoSlug is not set');
        }
        if (!this.config.commitSha) {
            throw new Error('Bitbucket commitSha is not set');
        }
    }
    async report(scan) {
        const issues = await scan.issues();
        if (issues.length === 0)
            return;
        const builder = this.createReportBuilder(issues);
        const { report, annotations } = builder.build();
        const reportId = builder.getReportId();
        await Promise.all([
            this.submitBitbucketReport(reportId, report, annotations),
            this.generateTestReport(issues)
        ]);
    }
    async submitBitbucketReport(reportId, report, annotations) {
        await this.bitbucketClient.createOrUpdateReport(reportId, report);
        await this.bitbucketClient.createAnnotations(reportId, annotations);
    }
    async generateTestReport(issues) {
        const testFilePath = this.testFilePathResolver.getTestFilePath();
        const junitBuilder = new junit_1.JUnitReportBuilder(issues, testFilePath);
        const testReport = junitBuilder.build();
        const reportXml = (0, junit_1.buildJUnitXML)(testReport);
        const fileName = this.generateUniqueFileName();
        await (0, promises_1.writeFile)(fileName, reportXml, 'utf-8');
    }
    generateUniqueFileName() {
        const baseFilename = this.config.testReportFilename || 'bb-test-report.xml';
        const ext = (0, node_path_1.extname)(baseFilename);
        const base = (0, node_path_1.basename)(baseFilename, ext);
        return `${base}-${(0, node_crypto_1.randomUUID)()}${ext}`;
    }
    createReportBuilder(issues) {
        const testFilePath = this.testFilePathResolver.getTestFilePath();
        return issues.length === 1
            ? new builders_1.SingleItemReportBuilder(issues[0], this.config.commitSha, testFilePath)
            : new builders_1.MultiItemsReportBuilder(issues, this.config.commitSha, testFilePath);
    }
};
exports.BitbucketReporter = BitbucketReporter;
exports.BitbucketReporter = BitbucketReporter = tslib_1.__decorate([
    (0, tsyringe_1.injectable)(),
    tslib_1.__param(0, (0, tsyringe_1.inject)(api_1.BITBUCKET_CONFIG)),
    tslib_1.__param(1, (0, tsyringe_1.inject)(api_1.BITBUCKET_CLIENT)),
    tslib_1.__param(2, (0, tsyringe_1.inject)(utils_1.TEST_FILE_PATH_RESOLVER)),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Object])
], BitbucketReporter);
//# sourceMappingURL=BitbucketReporter.js.map