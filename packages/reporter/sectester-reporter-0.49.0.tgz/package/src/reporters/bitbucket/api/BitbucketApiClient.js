"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BitbucketApiClient = void 0;
const tslib_1 = require("tslib");
const BitbucketConfig_1 = require("./BitbucketConfig");
const undici_1 = require("undici");
const tsyringe_1 = require("tsyringe");
let BitbucketApiClient = class BitbucketApiClient {
    constructor(config) {
        this.config = config;
        if (this.config.usePipelinesProxy && this.config.proxyUrl) {
            // Disable HTTP CONNECT tunneling - the Bitbucket Pipelines proxy
            // is a simple HTTP forward proxy that doesn't support CONNECT tunneling
            this.proxyAgent = new undici_1.ProxyAgent({
                uri: this.config.proxyUrl,
                proxyTunnel: false
            });
        }
    }
    async createOrUpdateReport(reportId, report) {
        const url = this.buildUrl(`/repositories/${this.config.workspace}/${this.config.repoSlug}/commit/${this.config.commitSha}/reports/${reportId}`);
        console.log('sdfjknsdjkndajknds', {
            proxyUrl: this.config.proxyUrl,
            agent: this.proxyAgent,
            url,
            body: JSON.stringify(report)
        });
        let res;
        try {
            res = await (0, undici_1.fetch)(url, {
                method: 'PUT',
                headers: this.getHeaders(),
                body: JSON.stringify(report),
                dispatcher: this.proxyAgent
            });
        }
        catch (e) {
            console.error(e);
            throw e;
        }
        if (!res.ok) {
            const errorBody = await res.text();
            throw new Error(`Bitbucket API error: ${res.status} ${res.statusText} - ${errorBody}`);
        }
    }
    async createAnnotations(reportId, annotations) {
        if (annotations.length === 0) {
            return;
        }
        const url = this.buildUrl(`/repositories/${this.config.workspace}/${this.config.repoSlug}/commit/${this.config.commitSha}/reports/${reportId}/annotations`);
        // Bitbucket API allows up to 100 annotations per request
        const chunks = this.chunkArray(annotations, 100);
        for (const chunk of chunks) {
            const res = await (0, undici_1.fetch)(url, {
                method: 'POST',
                headers: this.getHeaders(),
                body: JSON.stringify(chunk),
                dispatcher: this.proxyAgent
            });
            if (!res.ok) {
                const errorBody = await res.text();
                throw new Error(`Bitbucket API error: ${res.status} ${res.statusText} - ${errorBody}`);
            }
        }
    }
    buildUrl(path) {
        // When using the Pipelines proxy, use http:// instead of https://
        // The proxy handles authentication automatically
        const baseUrl = this.config.usePipelinesProxy
            ? 'http://api.bitbucket.org/2.0'
            : 'https://api.bitbucket.org/2.0';
        return `${baseUrl}${path}`;
    }
    getHeaders() {
        const headers = {
            'Content-Type': 'application/json'
        };
        // Only add authorization header when not using the Pipelines proxy
        // The proxy automatically adds authentication
        if (!this.config.usePipelinesProxy && this.config.token) {
            headers['authorization'] = `Bearer ${this.config.token}`;
        }
        return headers;
    }
    chunkArray(array, size) {
        const chunks = [];
        for (let i = 0; i < array.length; i += size) {
            chunks.push(array.slice(i, i + size));
        }
        return chunks;
    }
};
exports.BitbucketApiClient = BitbucketApiClient;
exports.BitbucketApiClient = BitbucketApiClient = tslib_1.__decorate([
    (0, tsyringe_1.injectable)(),
    tslib_1.__param(0, (0, tsyringe_1.inject)(BitbucketConfig_1.BITBUCKET_CONFIG)),
    tslib_1.__metadata("design:paramtypes", [Object])
], BitbucketApiClient);
//# sourceMappingURL=BitbucketApiClient.js.map