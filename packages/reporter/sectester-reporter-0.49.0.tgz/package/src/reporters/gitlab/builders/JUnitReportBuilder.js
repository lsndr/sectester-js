"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JUnitReportBuilder = void 0;
var JUnitReportBuilder_1 = require("../../../junit/JUnitReportBuilder");
Object.defineProperty(exports, "JUnitReportBuilder", { enumerable: true, get: function () { return JUnitReportBuilder_1.JUnitReportBuilder; } });
//# sourceMappingURL=JUnitReportBuilder.js.map